package com.smartscreen.control

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SessionRulesTest {
    @Test fun timedSessionRequestsDurationWithSmallMargin() {
        assertEquals(6 * 60_000, SessionRules.requestedTimeoutMs(5))
        assertEquals(16 * 60_000, SessionRules.requestedTimeoutMs(15))
        assertEquals(121 * 60_000, SessionRules.requestedTimeoutMs(120))
    }

    @Test fun indefiniteSessionOnlyAcceptsExtendedTimeout() {
        assertEquals(Int.MAX_VALUE, SessionRules.requestedTimeoutMs(null))
        assertTrue(SessionRules.acceptDeviceTimeout(Int.MAX_VALUE, null))
        assertFalse(SessionRules.acceptDeviceTimeout(30 * 60_000, null))
    }

    @Test fun deviceCapCannotShortenUserRequestedSession() {
        assertTrue(SessionRules.acceptDeviceTimeout(6 * 60_000, 5))
        assertTrue(SessionRules.acceptDeviceTimeout(5 * 60_000, 5))
        assertFalse(SessionRules.acceptDeviceTimeout(4 * 60_000, 5))
        assertFalse(SessionRules.acceptDeviceTimeout(30_000, 15))
        assertTrue(SessionRules.acceptDeviceTimeout(Int.MAX_VALUE, 120))
    }

    @Test fun timerBoundaries() {
        assertFalse(SessionRules.isTimedSessionExpired(100L, 101L))
        assertTrue(SessionRules.isTimedSessionExpired(100L, 100L))
        assertTrue(SessionRules.isTimedSessionExpired(101L, 100L))
        assertFalse(SessionRules.isTimedSessionExpired(101L, 0L))
        assertEquals(0L, SessionRules.remainingMs(200L, 100L))
        assertEquals(100L, SessionRules.remainingMs(100L, 200L))
    }

    @Test(expected = IllegalArgumentException::class)
    fun rejectZeroDuration() { SessionRules.requestedTimeoutMs(0) }

    @Test(expected = IllegalArgumentException::class)
    fun rejectTooLongDuration() { SessionRules.requestedTimeoutMs(721) }
}
