package com.smartscreen.control

import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import android.widget.Toast

/** Optional manual Quick Settings control. One tap toggles a 15-minute session. */
class ScreenQuickTileService : TileService() {
    override fun onStartListening() {
        super.onStartListening()
        refresh()
    }

    override fun onClick() {
        super.onClick()
        val controller = ScreenSettingsController(this)
        controller.reconcileSession()
        if (!controller.allowed()) {
            openAppForPermissions()
            return
        }
        val result = if (controller.isSessionActive()) {
            controller.stopSession()
        } else {
            controller.startSession(15)
        }
        Toast.makeText(this, result.message, Toast.LENGTH_SHORT).show()
        refresh()
    }

    private fun refresh() {
        val tile = qsTile ?: return
        val active = ScreenSettingsController(this).isSessionActive()
        tile.label = if (active) "إيقاف الإضاءة" else "إضاءة 15 دقيقة"
        tile.state = if (active) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        tile.updateTile()
    }

    private fun openAppForPermissions() {
        val intent = Intent(this, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        try {
            if (Build.VERSION.SDK_INT >= 34) {
                val pending = PendingIntent.getActivity(
                    this, 1550, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                startActivityAndCollapse(pending)
            } else {
                @Suppress("DEPRECATION")
                startActivityAndCollapse(intent)
            }
        } catch (_: Exception) {
            Toast.makeText(this, "افتح التطبيق لمنح إذن تعديل الإعدادات", Toast.LENGTH_LONG).show()
        }
    }
}
