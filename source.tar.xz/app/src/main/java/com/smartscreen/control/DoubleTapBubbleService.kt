package com.smartscreen.control

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs

/** Touch handling is confined to a visible 56dp bubble, never the full display. */
class DoubleTapBubbleService : Service() {
    private var wm: WindowManager? = null
    private var bubble: View? = null
    private var params: WindowManager.LayoutParams? = null
    private val channelId = "screen_bubble_v1"
    private val notificationId = 1642
    private val prefs by lazy { getSharedPreferences("floating_control_v1", MODE_PRIVATE) }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY }
        val dpm = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        if (!dpm.isAdminActive(ComponentName(this, ScreenAdminReceiver::class.java))) {
            stopSelf(); return START_NOT_STICKY
        }
        try {
            createChannel()
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(notificationId, notification(),
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            } else startForeground(notificationId, notification())
            if (bubble == null) createBubble()
        } catch (_: Exception) {
            Toast.makeText(this, "تعذر عرض الزر العائم", Toast.LENGTH_SHORT).show()
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(NotificationChannel(channelId,
                "زر قفل الشاشة العائم", NotificationManager.IMPORTANCE_LOW))
        }
    }

    private fun notification(): Notification {
        val pi = PendingIntent.getActivity(this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this, channelId)
            .setSmallIcon(R.drawable.ic_app)
            .setContentTitle("زر إطفاء الشاشة مفعّل")
            .setContentText("انقر مرتين على الزر العائم للقفل؛ افتح التطبيق لإخفائه")
            .setContentIntent(pi)
            .setOngoing(true)
            .setCategory(Notification.CATEGORY_SERVICE)
            .build()
    }

    private fun dp(n: Int): Int = (n * resources.displayMetrics.density + 0.5f).toInt()

    private fun createBubble() {
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val text = TextView(this).apply {
            text = "⏻"
            textSize = 28f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            contentDescription = "انقر مرتين لقفل الشاشة؛ اسحب لنقل الزر"
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.rgb(23, 112, 109))
                setStroke(dp(2), Color.WHITE)
            }
            elevation = dp(4).toFloat()
        }
        val lp = WindowManager.LayoutParams(
            dp(56), dp(56), WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = prefs.getInt("x", dp(6))
            y = prefs.getInt("y", dp(250))
        }
        var downX = 0f
        var downY = 0f
        var initialX = 0
        var initialY = 0
        var dragged = false
        var lastTapAt = 0L
        text.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX
                    downY = event.rawY
                    initialX = lp.x
                    initialY = lp.y
                    dragged = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - downX
                    val dy = event.rawY - downY
                    if (abs(dx) > dp(12) || abs(dy) > dp(12)) dragged = true
                    if (dragged) {
                        lp.x = initialX + dx.toInt()
                        lp.y = initialY + dy.toInt()
                        try { wm?.updateViewLayout(text, lp) } catch (_: Exception) { }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (dragged) {
                        lastTapAt = 0L
                        prefs.edit().putInt("x", lp.x).putInt("y", lp.y).apply()
                    } else {
                        val now = SystemClock.uptimeMillis()
                        if (lastTapAt > 0 && now - lastTapAt in 45..420) {
                            lastTapAt = 0L
                            lockScreen()
                        } else lastTapAt = now
                    }
                    true
                }
                MotionEvent.ACTION_CANCEL -> { lastTapAt = 0L; true }
                else -> false
            }
        }
        wm?.addView(text, lp)
        bubble = text
        params = lp
    }

    private fun lockScreen() {
        val dpm = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        val admin = ComponentName(this, ScreenAdminReceiver::class.java)
        if (dpm.isAdminActive(admin)) {
            try { dpm.lockNow() }
            catch (_: SecurityException) {
                Toast.makeText(this, "صلاحية قفل الجهاز غير متاحة", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onDestroy() {
        bubble?.let { view -> try { wm?.removeView(view) } catch (_: Exception) { } }
        bubble = null
        params = null
        super.onDestroy()
    }
}
