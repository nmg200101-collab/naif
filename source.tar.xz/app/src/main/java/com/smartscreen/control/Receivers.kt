package com.smartscreen.control

import android.app.admin.DeviceAdminReceiver
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class ScreenAdminReceiver : DeviceAdminReceiver()

class SessionAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == ScreenSettingsController.ACTION_EXPIRE) {
            ScreenSettingsController(context).reconcileSession()
        }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            Intent.ACTION_BOOT_COMPLETED, Intent.ACTION_TIME_CHANGED ->
                ScreenSettingsController(context).reconcileSession()
        }
    }
}
