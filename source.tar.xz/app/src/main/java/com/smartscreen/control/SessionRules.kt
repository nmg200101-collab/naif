package com.smartscreen.control

/** Pure session policy rules; no Android dependency, so tests run on a regular JVM. */
object SessionRules {
    private const val MINUTE_MS = 60_000L
    const val CONTINUOUS_TIMEOUT_MS = Int.MAX_VALUE

    /** Keep a modest one-minute margin for a time-limited session, not years of timeout. */
    fun requestedTimeoutMs(minutes: Int?): Int {
        if (minutes == null) return CONTINUOUS_TIMEOUT_MS
        require(minutes in 1..720) { "Session length must be between 1 and 720 minutes" }
        return ((minutes.toLong() + 1) * MINUTE_MS)
            .coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
    }

    /** The device's effective timeout must cover the requested session duration. */
    fun acceptDeviceTimeout(actualTimeoutMs: Int, minutes: Int?): Boolean {
        if (actualTimeoutMs == Int.MAX_VALUE) return true
        return minutes != null && minutes > 0 &&
            actualTimeoutMs.toLong() >= minutes.toLong() * MINUTE_MS
    }

    /** Do not misreport a session as active when its end was already reached. */
    fun isTimedSessionExpired(now: Long, until: Long): Boolean = until > 0 && now >= until
    fun remainingMs(now: Long, until: Long): Long = (until - now).coerceAtLeast(0L)
}
