package com.smartscreen.control

import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.ActivityNotFoundException
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast

/** Native Arabic-first interface. No network services or trackers. */
class MainActivity : Activity() {
    private lateinit var control: ScreenSettingsController
    private lateinit var dpm: DevicePolicyManager
    private lateinit var admin: ComponentName
    private val handler = Handler(Looper.getMainLooper())
    private val timeoutValues = intArrayOf(15, 30, 60, 120, 300, 600, 1800)
    private val timeoutLabels = arrayOf("15 ثانية", "30 ثانية", "دقيقة", "دقيقتان", "5 دقائق", "10 دقائق", "30 دقيقة")
    private lateinit var stateText: TextView
    private lateinit var countdownText: TextView
    private lateinit var permissionText: TextView
    private lateinit var currentTimeoutText: TextView
    private lateinit var brightnessText: TextView
    private lateinit var brightnessSeek: SeekBar
    private lateinit var timeoutSpinner: Spinner
    private val refreshRunnable = object : Runnable {
        override fun run() {
            refreshScreen()
            handler.postDelayed(this, 1_000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.layoutDirection = View.LAYOUT_DIRECTION_RTL
        setContentView(R.layout.activity_main)
        control = ScreenSettingsController(this)
        dpm = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        admin = ComponentName(this, ScreenAdminReceiver::class.java)
        stateText = findViewById(R.id.txtState)
        countdownText = findViewById(R.id.txtCountdown)
        permissionText = findViewById(R.id.txtPermissionState)
        currentTimeoutText = findViewById(R.id.txtCurrentTimeout)
        brightnessText = findViewById(R.id.txtBrightness)
        brightnessSeek = findViewById(R.id.seekBrightness)
        timeoutSpinner = findViewById(R.id.spinnerTimeout)
        timeoutSpinner.adapter = ArrayAdapter(this,
            android.R.layout.simple_spinner_dropdown_item, timeoutLabels)

        findViewById<Button>(R.id.btnPermission).setOnClickListener { requestWritePermission() }
        findViewById<Button>(R.id.btnAdmin).setOnClickListener { requestAdmin() }
        findViewById<Button>(R.id.btnOverlay).setOnClickListener { requestOverlayPermission() }
        findViewById<Button>(R.id.btn5).setOnClickListener { session(5) }
        findViewById<Button>(R.id.btn15).setOnClickListener { session(15) }
        findViewById<Button>(R.id.btn30).setOnClickListener { session(30) }
        findViewById<Button>(R.id.btn60).setOnClickListener { session(60) }
        findViewById<Button>(R.id.btn120).setOnClickListener { session(120) }
        findViewById<Button>(R.id.btnAlways).setOnClickListener { session(null) }
        findViewById<Button>(R.id.btnStop).setOnClickListener { show(control.stopSession()) }
        findViewById<Button>(R.id.btnApplyTimeout).setOnClickListener {
            show(control.setTimeout(timeoutValues[timeoutSpinner.selectedItemPosition]))
        }
        brightnessSeek.progress = ((control.currentBrightness() / 255.0) * 99).toInt()
        updateBrightnessLabel()
        brightnessSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
                updateBrightnessLabel()
            }
            override fun onStartTrackingTouch(seekBar: SeekBar) = Unit
            override fun onStopTrackingTouch(seekBar: SeekBar) = Unit
        })
        findViewById<Button>(R.id.btnApplyBrightness).setOnClickListener {
            show(control.setBrightness(brightnessSeek.progress + 1))
        }
        findViewById<Button>(R.id.btnRestoreBrightness).setOnClickListener {
            show(control.restoreBrightness())
        }
        findViewById<Button>(R.id.btnBubbleStart).setOnClickListener { startBubble() }
        findViewById<Button>(R.id.btnBubbleStop).setOnClickListener {
            stopService(Intent(this, DoubleTapBubbleService::class.java))
            toast("تم إرسال طلب إخفاء الزر العائم")
        }
        findViewById<Button>(R.id.btnLockNow).setOnClickListener { lockNow() }
        findViewById<Button>(R.id.btnWakeSettings).setOnClickListener {
            launchSettings(Intent(Settings.ACTION_DISPLAY_SETTINGS))
        }
        findViewById<Button>(R.id.btnRestoreAll).setOnClickListener {
            show(control.restoreAll())
        }
    }

    override fun onResume() {
        super.onResume()
        control.reconcileSession()
        handler.removeCallbacks(refreshRunnable)
        handler.post(refreshRunnable)
    }

    override fun onPause() {
        handler.removeCallbacks(refreshRunnable)
        super.onPause()
    }

    private fun session(minutes: Int?) { show(control.startSession(minutes)) }

    private fun show(result: ScreenSettingsController.Result) {
        Toast.makeText(this, result.message, Toast.LENGTH_LONG).show()
        refreshScreen()
    }

    private fun refreshScreen() {
        val grantedWrite = control.allowed()
        val grantedAdmin = dpm.isAdminActive(admin)
        val grantedOverlay = Settings.canDrawOverlays(this)
        permissionText.text = "إعدادات النظام: ${yes(grantedWrite)}   •   مسؤول الجهاز: ${yes(grantedAdmin)}\nالزر العائم: ${yes(grantedOverlay)}"
        val active = control.isSessionActive()
        val current = control.currentTimeoutMs()
        val until = control.sessionUntil()
        stateText.text = when {
            active && until == 0L -> "● الإضاءة المستمرة مفعلة"
            active -> "● جلسة إضاءة مؤقتة نشطة"
            else -> "○ لا توجد جلسة إضاءة نشطة"
        }
        countdownText.text = if (active && until > 0L) {
            val ms = (until - System.currentTimeMillis()).coerceAtLeast(0L)
            "الوقت المتبقي تقريبًا: ${ms / 3_600_000} س • ${(ms / 60_000) % 60} د • ${(ms / 1_000) % 60} ث"
        } else if (active) "مستمرة حتى إيقافها يدويًا (بحسب حدود الجهاز)" else "يمكنك اختيار مدة من القائمة"
        currentTimeoutText.text = if (current == Int.MAX_VALUE) "مهلة السكون الحالية: طويلة جدًا (مستمرة نظريًا)"
            else "مهلة السكون الفعلية: ${current / 1_000} ثانية"
        if (!brightnessSeek.isPressed) {
            // Preserve the slider selection while dragging; otherwise reflect system-level changes.
            // Do not forcibly refresh progress after every tick: that would erase a user's choice.
        }
        findViewById<Button>(R.id.btnPermission).text = if (grantedWrite) "✓ تعديل النظام مسموح" else "السماح بتعديل إعدادات الشاشة"
        findViewById<Button>(R.id.btnAdmin).text = if (grantedAdmin) "✓ قفل الشاشة مُفعّل" else "تفعيل قفل الشاشة (مسؤول الجهاز)"
        findViewById<Button>(R.id.btnOverlay).text = if (grantedOverlay) "✓ الظهور فوق التطبيقات مسموح" else "السماح بالزر العائم"
    }

    private fun yes(ok: Boolean) = if (ok) "مسموح ✓" else "غير مسموح"
    private fun updateBrightnessLabel() {
        brightnessText.text = "السطوع المطلوب: ${brightnessSeek.progress + 1}%"
    }
    private fun toast(message: String) { Toast.makeText(this, message, Toast.LENGTH_LONG).show() }

    private fun requestWritePermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            launchSettings(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS,
                Uri.parse("package:$packageName")))
        } else toast("هذا الإصدار من أندرويد لا يحتاج موافقة إضافية")
    }

    private fun requestAdmin() {
        if (dpm.isAdminActive(admin)) {
            toast("مسؤول الجهاز مفعّل بالفعل. يمكن إلغاء الصلاحية من إعدادات الهاتف")
            return
        }
        val i = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
            .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, admin)
            .putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                "تستخدم الصلاحية فقط عند طلب قفل الشاشة بالزر أو النقر المزدوج. لا يغيّر التطبيق كلمة المرور.")
        launchSettings(i)
    }

    private fun requestOverlayPermission() {
        if (Settings.canDrawOverlays(this)) {
            toast("السماح بالظهور فوق التطبيقات مُفعّل")
            return
        }
        launchSettings(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:$packageName")))
    }

    private fun launchSettings(intent: Intent) {
        try { startActivity(intent) }
        catch (_: ActivityNotFoundException) {
            try { startActivity(Intent(Settings.ACTION_SETTINGS)) }
            catch (_: Exception) { toast("تعذر فتح الإعدادات على هذا الهاتف") }
        } catch (_: SecurityException) { toast("منع النظام فتح هذه الإعدادات") }
    }

    private fun lockNow() {
        if (!dpm.isAdminActive(admin)) { requestAdmin(); return }
        try { dpm.lockNow() }
        catch (_: SecurityException) { toast("تعذر قفل الشاشة: تحقق من صلاحية مسؤول الجهاز") }
    }

    private fun startBubble() {
        if (!dpm.isAdminActive(admin)) { requestAdmin(); return }
        if (!Settings.canDrawOverlays(this)) { requestOverlayPermission(); return }
        val intent = Intent(this, DoubleTapBubbleService::class.java)
        try {
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent)
            else startService(intent)
            toast("سيظهر زر عائم. اضغط عليه مرتين سريعًا للقفل")
        } catch (_: Exception) { toast("تعذر تشغيل الزر العائم؛ راجع قيود التشغيل في الخلفية") }
    }
}
