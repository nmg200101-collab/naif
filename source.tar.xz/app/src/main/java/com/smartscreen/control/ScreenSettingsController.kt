package com.smartscreen.control

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Settings

/** Controls system-wide settings only after explicit WRITE_SETTINGS approval. */
class ScreenSettingsController(private val context: Context) {
    private val prefs = context.getSharedPreferences("screen_controller_v1", Context.MODE_PRIVATE)
    private val resolver = context.contentResolver

    companion object {
        private const val TIMEOUT_ORIGINAL = "timeout_original"
        private const val TIMEOUT_APPLIED = "timeout_applied"
        private const val SESSION_ACTIVE = "session_active"
        private const val SESSION_UNTIL = "session_until_wall_ms"
        private const val BRIGHTNESS_ORIGINAL = "brightness_original"
        private const val BRIGHTNESS_MODE_ORIGINAL = "brightness_mode_original"
        private const val BRIGHTNESS_APPLIED = "brightness_applied"
        private const val NO_VALUE = -1
        const val INDEFINITE_TIMEOUT_MS = SessionRules.CONTINUOUS_TIMEOUT_MS
        const val ACTION_EXPIRE = "com.smartscreen.control.ACTION_EXPIRE"
    }

    data class Result(val ok: Boolean, val message: String)

    fun allowed(): Boolean = Build.VERSION.SDK_INT < 23 || Settings.System.canWrite(context)

    fun currentTimeoutMs(): Int = Settings.System.getInt(resolver, Settings.System.SCREEN_OFF_TIMEOUT, 30_000)
    fun currentBrightness(): Int = Settings.System.getInt(resolver, Settings.System.SCREEN_BRIGHTNESS, 128)
    fun currentBrightnessMode(): Int = Settings.System.getInt(resolver, Settings.System.SCREEN_BRIGHTNESS_MODE, 0)
    fun isSessionActive(): Boolean = prefs.getBoolean(SESSION_ACTIVE, false)
    fun sessionUntil(): Long = prefs.getLong(SESSION_UNTIL, 0L)
    fun hasPendingRestoration(): Boolean = prefs.contains(TIMEOUT_ORIGINAL) || prefs.contains(BRIGHTNESS_ORIGINAL)

    /** The temporary session changes the phone's inactivity timeout globally. OEM/policy limits still apply. */
    @Synchronized
    fun startSession(minutes: Int?): Result {
        if (!allowed()) return Result(false, "اسمح للتطبيق بتعديل إعدادات النظام أولًا")
        if (minutes != null && minutes !in 1..720) return Result(false, "المدة غير صالحة")
        val target = SessionRules.requestedTimeoutMs(minutes)
        val previous = currentTimeoutMs()
        val didWrite = try { Settings.System.putInt(resolver, Settings.System.SCREEN_OFF_TIMEOUT, target) }
            catch (_: SecurityException) { false }
        if (!didWrite) return Result(false, "رفض الهاتف تعديل مهلة السكون")
        val actual = currentTimeoutMs()
        if (!SessionRules.acceptDeviceTimeout(actual, minutes)) {
            // Indefinite sessions require true extended timeout support. For timed
            // sessions, an OEM cap is acceptable only when it covers the full duration.
            if (actual != previous) try { Settings.System.putInt(resolver, Settings.System.SCREEN_OFF_TIMEOUT, previous) }
                catch (_: SecurityException) { }
            return Result(false, "الهاتف يقيّد مهلة السكون إلى ${actual / 1_000} ثانية؛ لا يمكن ضمان المدة المطلوبة")
        }
        val editor = prefs.edit()
        if (!prefs.contains(TIMEOUT_ORIGINAL)) editor.putInt(TIMEOUT_ORIGINAL, previous)
        val end = if (minutes == null) 0L else System.currentTimeMillis() + minutes * 60_000L
        val saved = editor.putInt(TIMEOUT_APPLIED, actual)
            .putBoolean(SESSION_ACTIVE, true)
            .putLong(SESSION_UNTIL, end)
            .commit()
        if (!saved) {
            // State must survive process death; otherwise do not leave an untracked override.
            if (actual == currentTimeoutMs()) {
                try { Settings.System.putInt(resolver, Settings.System.SCREEN_OFF_TIMEOUT, previous) }
                catch (_: SecurityException) { }
            }
            return Result(false, "تعذر حفظ الجلسة؛ تمت محاولة إعادة إعدادات الشاشة")
        }
        if (end > 0) scheduleExpiry(end) else cancelExpiry()
        updateQuickTile()
        val capInfo = if (actual != target) " (مهلة الهاتف الفعلية: ${actual / 60_000} دقيقة)" else ""
        return Result(true, if (end == 0L) "تم اختيار الإضاءة المستمرة؛ يمكن إنهاؤها من التطبيق" else
            "بدأت جلسة مدتها $minutes دقيقة$capInfo")
    }

    /** Sets a standard system inactivity timeout, independent of app lifetime. */
    @Synchronized
    fun setTimeout(seconds: Int): Result {
        if (!allowed()) return Result(false, "اسمح بتعديل إعدادات النظام أولًا")
        if (seconds !in 15..3600) return Result(false, "المدة غير صالحة")
        val old = currentTimeoutMs()
        val target = seconds * 1_000
        val wrote = try { Settings.System.putInt(resolver, Settings.System.SCREEN_OFF_TIMEOUT, target) }
            catch (_: SecurityException) { false }
        if (!wrote) return Result(false, "تعذر تحديث المهلة")
        val actual = currentTimeoutMs()
        if (actual != target) {
            if (actual != old) try {
                Settings.System.putInt(resolver, Settings.System.SCREEN_OFF_TIMEOUT, old)
            } catch (_: SecurityException) { }
            return Result(false, "الهاتف لا يقبل مهلة $seconds ثانية؛ تمت محاولة استعادة المهلة السابقة")
        }
        val editor = prefs.edit()
        if (!prefs.contains(TIMEOUT_ORIGINAL)) editor.putInt(TIMEOUT_ORIGINAL, old)
        val saved = editor.putInt(TIMEOUT_APPLIED, actual)
            .putBoolean(SESSION_ACTIVE, false)
            .remove(SESSION_UNTIL).commit()
        if (!saved) return Result(false, "لم تُحفَظ حالة المهلة؛ افتح الإعدادات للتحقق منها")
        cancelExpiry()
        updateQuickTile()
        return Result(true, "تم تعيين مهلة السكون إلى $seconds ثانية")
    }

    @Synchronized
    fun stopSession(): Result {
        if (!prefs.contains(TIMEOUT_ORIGINAL) && !isSessionActive())
            return Result(true, "لا توجد جلسة أو مهلة محفوظة تحتاج إلى استعادة")
        if (!allowed()) return Result(false, "أعِد إذن تعديل النظام لاستعادة المهلة السابقة")
        val orig = prefs.getInt(TIMEOUT_ORIGINAL, NO_VALUE)
        val last = prefs.getInt(TIMEOUT_APPLIED, NO_VALUE)
        val current = currentTimeoutMs()
        if (orig != NO_VALUE && last == current) {
            val wrote = try { Settings.System.putInt(resolver, Settings.System.SCREEN_OFF_TIMEOUT, orig) }
                catch (_: SecurityException) { false }
            if (!wrote) return Result(false, "تعذرت استعادة المهلة الأصلية")
            if (currentTimeoutMs() != orig) return Result(false, "قيّد النظام استعادة المهلة الأصلية")
        }
        prefs.edit().remove(TIMEOUT_ORIGINAL).remove(TIMEOUT_APPLIED)
            .putBoolean(SESSION_ACTIVE, false).remove(SESSION_UNTIL).commit()
        cancelExpiry()
        updateQuickTile()
        return Result(true, if (orig != NO_VALUE && current != last)
            "كانت مهلة السكون قد تغيرت خارج التطبيق؛ تُرك إعداد الهاتف الجديد كما هو"
        else "أُوقفت الجلسة، واستُعيدت مهلة السكون السابقة")
    }

    /** Stop or re-arm timed sessions when triggered by alarm, reboot, or app resuming. */
    @Synchronized
    fun reconcileSession() {
        if (!isSessionActive()) return
        val until = sessionUntil()
        if (until == 0L) return
        if (SessionRules.isTimedSessionExpired(System.currentTimeMillis(), until)) {
            if (allowed()) stopSession()
        } else scheduleExpiry(until)
    }

    @Synchronized
    fun setBrightness(percent: Int): Result {
        if (!allowed()) return Result(false, "اسمح بتعديل إعدادات النظام أولًا")
        if (percent !in 1..100) return Result(false, "السطوع يجب أن يكون بين 1 و100%")
        val old = currentBrightness()
        val oldMode = currentBrightnessMode()
        val target = 1 + (percent - 1) * 254 / 99
        val modeOk = try {
            Settings.System.putInt(resolver, Settings.System.SCREEN_BRIGHTNESS_MODE,
                Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
        } catch (_: SecurityException) { false }
        if (!modeOk) return Result(false, "تعذر إيقاف السطوع التلقائي")
        val wrote = try { Settings.System.putInt(resolver, Settings.System.SCREEN_BRIGHTNESS, target) }
            catch (_: SecurityException) { false }
        if (!wrote) {
            try { Settings.System.putInt(resolver, Settings.System.SCREEN_BRIGHTNESS_MODE, oldMode) }
            catch (_: SecurityException) { }
            return Result(false, "تعذر ضبط السطوع")
        }
        val editor = prefs.edit()
        if (!prefs.contains(BRIGHTNESS_ORIGINAL)) {
            editor.putInt(BRIGHTNESS_ORIGINAL, old)
                .putInt(BRIGHTNESS_MODE_ORIGINAL, oldMode)
        }
        val actual = currentBrightness()
        editor.putInt(BRIGHTNESS_APPLIED, actual).commit()
        return Result(actual == target, if (actual == target)
            "تم ضبط السطوع يدويًا إلى $percent%؛ يمكن استعادته لاحقًا" else
            "غيّر الهاتف قيمة السطوع المطلوبة؛ تم حفظ السطوع الفعلي ${actual * 100 / 255}%")
    }

    @Synchronized
    fun restoreBrightness(): Result {
        val old = prefs.getInt(BRIGHTNESS_ORIGINAL, NO_VALUE)
        if (old == NO_VALUE) return Result(true, "لا يوجد سطوع سابق لاستعادته")
        if (!allowed()) return Result(false, "أعِد إذن تعديل النظام لاستعادة السطوع")
        val applied = prefs.getInt(BRIGHTNESS_APPLIED, NO_VALUE)
        val unchanged = currentBrightness() == applied &&
            currentBrightnessMode() == Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL
        if (unchanged) {
            val oldMode = prefs.getInt(BRIGHTNESS_MODE_ORIGINAL,
                Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
            try {
                if (!Settings.System.putInt(resolver, Settings.System.SCREEN_BRIGHTNESS, old) ||
                    !Settings.System.putInt(resolver, Settings.System.SCREEN_BRIGHTNESS_MODE, oldMode))
                    return Result(false, "تعذرت استعادة إعداد السطوع السابق")
            } catch (_: SecurityException) { return Result(false, "تعذرت استعادة السطوع: الإذن مفقود") }
        }
        prefs.edit().remove(BRIGHTNESS_ORIGINAL).remove(BRIGHTNESS_MODE_ORIGINAL)
            .remove(BRIGHTNESS_APPLIED).commit()
        return Result(true, if (unchanged) "استُعيد السطوع السابق ووضعه الأصلي" else
            "تغير السطوع خارج التطبيق؛ لم يتم استبدال إعداد المستخدم الحالي")
    }

    fun restoreAll(): Result {
        val timeout = stopSession()
        val brightness = restoreBrightness()
        return Result(timeout.ok && brightness.ok, "${timeout.message}\n${brightness.message}")
    }

    private fun updateQuickTile() {
        if (Build.VERSION.SDK_INT >= 24) {
            try {
                android.service.quicksettings.TileService.requestListeningState(
                    context, android.content.ComponentName(context, ScreenQuickTileService::class.java)
                )
            } catch (_: Exception) { /* Optional UI capability, never block screen settings. */ }
        }
    }

    private fun expiryPendingIntent(): PendingIntent {
        val intent = Intent(context, SessionAlarmReceiver::class.java).setAction(ACTION_EXPIRE)
        return PendingIntent.getBroadcast(context, 4250, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun scheduleExpiry(end: Long) {
        val alarms = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = expiryPendingIntent()
        alarms.cancel(pi)
        // Inexact by design: does not require special exact alarm access. Doze may delay expiry.
        alarms.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, end, pi)
    }

    private fun cancelExpiry() {
        val alarms = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        alarms.cancel(expiryPendingIntent())
    }
}
